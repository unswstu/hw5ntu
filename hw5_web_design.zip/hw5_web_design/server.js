const express = require('express');
const bodyParser= require('body-parser');
const app = express();

const MongoClient = require('mongodb').MongoClient
















MongoClient.connect('mongodb+srv://ntuacc:ntuacc123@cluster0.wchmj.mongodb.net/test?retryWrites=true&w=majority', { useUnifiedTopology: true })
  .then(client => {
    console.log('台大學生上課簽到系統')

    const db = client.db('test')

    const quotesCollection = db.collection('quotes')

    
    

    app.use(bodyParser.urlencoded({ extended: true }))

    app.get('/', (req, res) => {


      db.collection('quotes').find().toArray()
      .then(results => {


        
        console.log(results)


      })


      
      .catch(error => console.error(error))


      

      

  




      res.sendFile(__dirname + '/index.html')
      
    })


    app.post('/quotes', (req, res) => {
      quotesCollection.insertOne(req.body)
      .then(result => {
        res.redirect('/')
      })
      .catch(error => console.error(error))
         
      })







    app.listen(3000, function() {
        console.log('學生簽到名單')
      })












  })
  .catch(error => console.error(error))
